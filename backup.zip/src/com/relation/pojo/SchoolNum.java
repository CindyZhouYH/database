package com.relation.pojo;

public class SchoolNum {
    private int length;

    public SchoolNum() {
    }

    public SchoolNum(int length) {
        this.length = length;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }
}
